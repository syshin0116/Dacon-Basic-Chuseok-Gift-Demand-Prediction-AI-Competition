from django.db import models


# Create your models here.
class Survey(models.Model):
    survey_idx = models.IntegerField()
    survey_question = models.CharField(max_length=100)
    survey_choices = models.CharField(max_length=100)

    def __str__(self):
        return self.survey_idx, ",", self.survey_question, ",", self.survey_choices