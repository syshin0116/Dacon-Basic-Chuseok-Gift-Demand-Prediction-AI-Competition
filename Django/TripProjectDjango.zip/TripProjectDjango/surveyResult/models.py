from django.db import models

# Create your models here.

class SurveyResult(models.Model):
    surveyResult_idx = models.IntegerField()
    member_idx = models.IntegerField()
    surveyResult_date = models.DateTimeField(auto_now=False, auto_now_add=False)
    surveyResult_answers = models.CharField(max_length=100)
    surveyResult_recommendation = models.CharField(max_length=100)
    surveyResult_rarea = models.CharField(max_length=100)

    def __str__(self):
        return self.surveyResult_idx, ', ', self.member_idx, ', ', self.surveyResult_date, ', ', self.surveyResult_answers, \
               self.surveyResult_recommendation, ', ', self.surveyResult_rarea

