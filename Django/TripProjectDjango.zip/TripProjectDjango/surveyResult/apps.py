from django.apps import AppConfig


class SurveyResultConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'surveyResult'
