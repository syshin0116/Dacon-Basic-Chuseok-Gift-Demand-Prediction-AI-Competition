from django.db import models


# Create your models here.
class Member(models.Model):
    member_idx = models.CharField(max_length=100)
    member_id = models.CharField(max_length=100)
    member_pw = models.CharField(max_length=100)
    member_name = models.CharField(max_length=100)
    member_birth = models.DateTimeField(auto_now=False, auto_now_add=False)
    member_addr = models.CharField(max_length=100)
    member_gender = models.IntegerField()
    member_naver_token = models.CharField(max_length=100)
    member_google_token = models.CharField(max_length=100)

    def __str__(self):
        return self.member_idx, ',', self.member_id, ',', self.member_pw, \
               ',', self.member_name, ',', self.member_birth, ',', self.member_addr, \
               ',', self.member_gender, ',', self.member_naver_token, ',', self.member_google_token
