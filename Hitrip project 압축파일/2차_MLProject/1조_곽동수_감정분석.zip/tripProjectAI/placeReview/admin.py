from django.contrib import admin

# Register your models here.
from placeReview.models import review

admin.site.register(review)