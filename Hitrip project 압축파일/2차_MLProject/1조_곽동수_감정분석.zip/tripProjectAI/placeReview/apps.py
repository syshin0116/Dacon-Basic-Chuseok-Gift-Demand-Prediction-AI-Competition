from django.apps import AppConfig


class PlacereviewConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'placeReview'
